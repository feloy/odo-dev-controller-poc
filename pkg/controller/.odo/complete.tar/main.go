package main

import (
	"fmt"
	"net/http"
)

func main() {
	http.HandleFunc("/", SalutServer)
	http.ListenAndServe("0.0.0.0:8080", nil)
}

func SalutServer(w http.ResponseWriter, r *http.Request) {
     fmt.Println("got resquest")
     fmt.Fprintf(w, "Salut, %s!", r.URL.Path[1:])
}
